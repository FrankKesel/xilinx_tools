**Note** : No input images are provided for the RGBIR testcases. Please acquire bayer images containing IR data on your own for running these cases. Current supported bayer formats are GR and BG.
