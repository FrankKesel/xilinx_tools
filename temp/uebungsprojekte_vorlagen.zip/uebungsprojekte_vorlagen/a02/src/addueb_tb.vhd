
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity addueb_tb is
end addueb_tb ;


architecture sim of addueb_tb is
  signal a       : std_logic_vector(3 downto 0) := "0000";
  signal b       : std_logic_vector(3 downto 0) := "0000";
  signal s    : std_logic_vector(3 downto 0);
  signal sumtest : signed(3 downto 0) := "0000";
  signal ov, ovtest   : std_logic;

  component addueb
    port (
      a    : in     std_logic_vector (3 downto 0);
      b    : in     std_logic_vector (3 downto 0);
      ov   : out    std_logic ;
      s    : out    std_logic_vector (3 downto 0)
      );
  end component;


begin
  -- instance port mappings.
  uut : addueb
    port map (
      a    => a,
      b    => b,
      ov   => ov,
      s    => s
      );

  gen_proc: process
  begin  -- process test
    for i in 1 to 16 loop
      for n in 1 to 16 loop
        wait for 1 ns;
        a <= std_logic_vector(unsigned(a) +1);
        wait for 1 ns;
        assert sumtest = signed(s)
          report "the sum is wrong.";    
        assert ovtest = ov
          report "the overflow is wrong.";
      end loop;  -- n
      b <= std_logic_vector(unsigned(b)+1);
    end loop;  -- i
    wait for 1 ns;
    report "simulation finished!";
  end process;

  comp_proc : process(a, b)
    variable sum_var : signed(3 downto 0) := "0000";
  begin
    sum_var := signed(a) + signed(b);
    ovtest <= (a(3) and b(3) and not sum_var(3)) 
  		or (not a(3) and not b(3) and sum_var(3));
    sumtest <= sum_var;  
  end process;

end;
