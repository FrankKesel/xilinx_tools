library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity addueb is
   port( 
      a  : in     std_logic_vector (3 downto 0);
      b  : in     std_logic_vector (3 downto 0);
      ov : out    std_logic;
      s  : out    std_logic_vector (3 downto 0)
   );
end addueb ;

architecture beh of addueb is
    
begin



end beh;
