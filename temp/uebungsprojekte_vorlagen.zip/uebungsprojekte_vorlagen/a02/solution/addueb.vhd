library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity addueb is
   port( 
      a  : in     std_logic_vector (3 downto 0);
      b  : in     std_logic_vector (3 downto 0);
      ov : out    std_logic;
      s  : out    std_logic_vector (3 downto 0)
   );
end addueb ;

architecture beh of addueb is
    signal ai, bi, si : signed(3 downto 0);
begin

    ai <= signed(a);
    bi <= signed(b);
    si <= ai + bi;
    s <= std_logic_vector(si);
    ov <= (ai(3) and bi(3) and not si(3)) 
		or (not ai(3) and not bi(3) and si(3));


end beh;
