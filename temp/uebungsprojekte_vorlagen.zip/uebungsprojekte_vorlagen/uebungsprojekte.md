# Übungsprojekte VHDL

Autor: F.Kesel, 16.04.2026

---
## Vorbemerkungen

Die folgenden Übungsprojekte können ohne vorhandenes FPGA-Board durchgeführt werden. Die Projekte sollen dazu dienen, dass Sie das Umsetzen von Aufgabenstellungen in VHDL-Code üben können. Im einfachsten Fall benötigen Sie nur einen Editor und einen Simulator mit Waveform-Viewer, um den VHDL-Code schreiben und simulieren zu können. Unter Linux ist beispielsweise der GHDL-Simulator empfehlenswert (https://ghdl.github.io) und Visual Studio Code als Editor (mit entsprechenen Extensions für VHDL). Als Waveform-Viewer kann GTKWave benutzt werden. Wenn Sie weitere Schritte wie Logiksynthese und Place&Route mit den Projekten durchführen möchten, dann müssten Sie sich die Xilinx Vivado Entwicklungsumgebung installieren. Sie erhalten diese kostenfrei von https://www.xilinx.com/support/download.html. Es ist allerdings so, dass Vivado sehr ressourcen-hungrig ist. Für die Installation benötigen Sie ca. 60 - 80 GByte Platz auf der Festplatte und bei der Ausführung sollten Sie einen schnellen Computer mit ausreichend Hauptspeicher haben. Ein Argument für die Verwendung von Vivado wäre die Logiksynthese, die Ihnen aufzeigen kann, ob Ihr Code synthesegerecht ist. Vom Autor dieses Dokuments ist ein Tutorial für Xilinx Vivado erhältlich (https://github.com/FrankKesel/xilinx_tools/blob/main/vivado/vivado_intro/vivado_intro.md).

Für alle Projekte sind Vorlagen vorhanden, diese können Sie als Zip-Datei erhalten. In der Verzeichnisstruktur finden Sie für jedes Projekt ein Unterverzeichnis. Darin ist jeweils ein weiteres Unterverzeichnis `src` mit den Quellcode-Vorlagen enthalten. Wenn Sie mit Vivado arbeiten, dann erstellen Sie im Projektverzeichnis ein Vivado-Projekt (siehe Tutorial) und binden die Quellen aus dem Verzeichnis `src` mit ein. Für jedes Projekt ist eine Testbench im Verzeichnis `src` mit dabei, die Sie aber ggf. noch erweitern müssen. Für das Design ist ebenfalls ein Code-Gerüst vorhanden, was Sie ergänzen müssen. Wenn Sie nicht weiter kommen, dann finden Sie jeweils im Unterverzeichnis `solution` die Lösung in Form des Quellcodes. Sehen Sie sich aber diese Lösung zunächst nicht an und versuchen Sie die Aufgabe selbst zu lösen. 


---
## Projekt 1

Im ersten Projekt sollen Sie das "Debuggen" von VHDL-Code üben. Vorgegeben sind zwei VHDL-Dateien: Der VHDL-Code für das "Design" (`edge.vhd`) und eine Testbench (`edge_tb.vhd`), um den Code simulieren zu können. Die Testbench ist korrekt und kann ohne Änderung benutzt werden. Die Design-Komponente soll folgende Funktion haben: Wenn am Eingang `edge_in` eine _steigende_ Flanke angelegt wird, dann soll zwei Takte später am Port `edge_out`  für einen Takt eine '1' ausgegeben werden, anderenfalls soll am Port eine '0' ausgegeben werden.

Im Code sind syntaktische und funktionale Fehler vorhanden. Verwenden Sie einen der oben angegebenen Simulatoren, setzen Sie damit ein Projekt bestehend aus den beiden Quelldateien auf und korrigieren Sie zunächst die Syntaxfehler. Sie können den Code zunächst inspizieren und Fehler korrigieren, die Ihnen auffallen. Ansonsten sehen Sie sich Fehlermeldungen des Simulators beim Kompilieren des Codes an (GHDL: **elaborate**). Bei mehreren Fehlermeldungen arbeiten Sie die Liste von oben nach unten ab: Korrigieren Sie zunächst den ersten Fehler in der Liste und kompilieren Sie erneut. Dann korrigieren Sie wieder die verbleibenden Fehler und kompilieren wieder. Der Grund für das Vorgehen liegt daran, dass durch Korrektur des ersten Fehlers u.U. weiter unten liegende Fehler ebenfalls korrigiert sind, wenn z.B. ein Package falsch eingebunden wurde. 

Simulieren Sie nun den Code: Sie werden feststellen, dass er nicht wie oben beschrieben funktioniert. Untersuchen Sie den Code der Design-Komponente `edge.vhd` und überlegen Sie, woran das liegen könnte. Zu Ihrer Information: Es sind zwei funktionale Fehler vorhanden. Machen Sie sich dazu zunächst klar, wie die Flankenerkennung funktionieren sollte, indem Sie ein Schaltbild zeichnen (es sind 3 Flipflops).

---
## Projekt 2

Schreiben Sie einen 4-Bit-Addierer in VHDL, der vorzeichenbehaftete Zahlen verarbeiten kann und mit einem Overflow-Port/Signal die Zahlenbereichsüberschreitung signalisiert (1-aktiv). Realisieren Sie die eigentliche Addition mit Hilfe des Additionsoperators für _signed_-Zahlen und erzeugen Sie das Overflow-Signal durch boole'sche Operatoren. Stellen Sie hierzu beispielsweise eine Funktionstabelle auf, aus der Sie die benötigte boole'sche Gleichung gewinnen. Eine Zahlenbereichsüberschreitung bei vorzeichbehafteten Zahlen liegt in folgenden Fällen vor:

* Beide Operanden sind positiv (Vorzeichenbits = '0') und das Ergebnis ist negativ (Vorzeichenbit = '1').
* Beide Operanden sind negativ (Vorzeichenbits = '1') und das Ergebnis ist positiv (Vorzeichenbit = '0').

Der Code des Addierers soll rein kombinatorisch sein, es werden also keine Flipflops und Register benötigt und damit auch kein Takt und Reset! Sie können den Code mit nebenläufigen Anweisungen schreiben oder mit expliziten Prozessen. Gehen Sie in zwei Schritten vor: Codieren und testen Sie erst den Addierer ohne Overflow und fügen Sie danach die Overflow-Funktionalität hinzu. Verwenden Sie die Datei `addueb.vhd`, darin ist die Entity und ein Gerüst für die Architecture schon vorgegeben, das Sie benutzen können. Für die Simulation ist eine Testbench in der Datei `addueb_tb.vhd` vorgegeben, die alle möglichen Zahlenkombinationen an das Design anlegt und jeweils prüft, ob Summe und Overflow korrekt sind. Die Testbench können Sie ohne Änderung benutzen.  

---
## Projekt 3

Schreiben Sie bitte eine VHDL-Komponente mit welcher die so genannte „Fibonacci-Folge“ gemäß folgender Formel berechnet werden kann :
**f(n) = f(n−1) + f(n−2) für n > 2 mit f(1) = f(2) = 1**

Ihre VHDL-Komponente soll getaktet sein und nach dem Reset mit jedem neuen Taktschritt (steigende Taktflanke) einen neuen Zahlenwert der Fibonacci-Folge am Port `fibo_out` generieren (für n > 2, der erste generierte Wert ist also = 2!).

Verwenden Sie die Datei `a3.vhd` in welcher die Entity und ein Gerüst für die Architecture vorgegeben ist. Zeichnen Sie vorher bitte ein RTL-Diagramm für die Architektur, die Sie implementieren möchten. Rechnen Sie bitte mit ganzen Zahlen und wählen Sie hierfür einen geeigneten Datentyp. Die Ausgangsbreite für die Fibonacci-Werte ist 16 Bit und somit ist der maximale Fibonacci-Wert begrenzt. Für die Simulation ist die Testbench-Datei `a3_tb.vhd` mit einem Gerüst vorgegeben. Ergänzen Sie den Code der Testbench, so dass die Folge der ersten 5 Fibonacci-Zahlen erzeugt wird und überprüfen Sie in der Testbench, dass es die korrekten Fibonacci-Zahlen sind. Rechnen Sie sich die erwarteten Werte dazu vorher aus.

---
## Projekt 4

Entwickeln Sie ein Steuerwerk in VHDL, welches folgende Aufgabe hat: Es sei zu
überprüfen, ob ein Signal `din` über mindestens zwei Taktperioden hinweg
den Wert '1' aufweist. Dieser Test soll nur dann ausgeführt werden,
wenn über ein weiteres Signal `start` = '1' eine Freigabe erteilt
wird. Wenn das Signal `start` = '0' ist, soll das Steuerwerk in den
Grundzustand übergehen. Wenn der Test erfolgreich war, soll das Steuerwerk ein
Signal `detect` auf '1' setzen und so lange gesetzt bleiben
bis `start` wieder auf '0' rückgesetzt wird. Über ein
'1'-aktives asynchrones Reset-Signal soll das Steuerwerk in den
Grundzustand gesetzt werden. Das Signal `din` sei ein asynchrones Signal
und soll über zwei Flipflops vor der Weiterverarbeitung synchronisiert werden.
Schreiben Sie auch eine Testbench für das Design und überprüfen Sie die Funktion
durch eine Simulation. Für das Design und die Testbench sind zwei entsprechende Quellcode-Dateien mit einem VHDL-Gerüst vorgegeben.


