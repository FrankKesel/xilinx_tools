library ieee;
use ieee.std_logic_1164.all;

entity edge is
	port (
		clk, reset, edge_in  : in  std_logic;
		edge_out	: out  std_logic);
end edge;

architecture behavioral of edge is
	signal s0, s1, s2 : std_logic;
begin

	process(clk, reset)
	begin
		if reset = '1' then
			s0 <= '0';
			s1 <= '0';
			s2 <= '0';
		elsif clk'event and clk = '1' then
			s0 <= edge_in;
			s1 <= s0;
			s2 <= s1;
		end if;
	end process;

	process(s1, s2)
	begin
	   edge_out <= not s2 and s1;
    end process;
	
end architecture behavioral;
