library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity edge_tb is
end edge_tb;

architecture sim of edge_tb is

    component edge is
        port (
            clk, reset, edge_in  : in  std_logic;
            edge_out	: out  std_logic);
    end component;

    constant clk_hz : integer := 100e6;
    constant clk_period : time := 1 sec / clk_hz;

    signal clk : std_logic := '0';
    signal rst : std_logic := '1';
    signal edge_in : std_logic := '0';
    signal edge_out : std_logic;

begin

    clk <= not clk after clk_period / 2;

    uut : edge
    port map (
        clk => clk,
        reset => rst,
        edge_in => edge_in,
        edge_out => edge_out
    );

    stimulus : process
    begin
        wait for clk_period * 2;
        rst <= '0';
        wait for clk_period * 5;
        edge_in <= '1';
        wait for clk_period * 2;
        assert edge_out = '1' report "edge_out wrong!";

        wait for clk_period * 10;
        report "Simulation finished!";
        wait;
        
    end process;

end;
