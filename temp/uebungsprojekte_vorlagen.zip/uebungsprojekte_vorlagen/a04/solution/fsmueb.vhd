library ieee;
use ieee.std_logic_1164.all;

entity fsmueb is
   port( 
      clk    : in     std_logic;
      din    : in     std_logic;
      res    : in     std_logic;
      start  : in     std_logic;
      detect : out    std_logic
   );
end fsmueb ;

architecture beh of fsmueb is
  type state_t is (s0, s1, s2);
  signal nstate, state : state_t;
  signal di : std_logic_vector(1 downto 0);
begin

  sreg: process (clk, res)
  begin
    if res = '1' then  
      state <= s0;
      di <= "00";
    elsif clk'event and clk = '1' then 
      state <= nstate; -- zustandsregister
      di(0) <= din;    -- synchronisation stufe 1
      di(1) <= di(0);  -- synchronisation stufe 2
    end if;
  end process sreg;

  uasn: process (state, start, di(1))
  begin
    detect <= '0';  -- default-zuweisung ausgabe
    nstate <= s0;   -- default-zuweisung naechster zustand
    case state is
      when s0 =>
        if start = '1' and di(1) = '1' then
          nstate <= s1;
        end if;
      when s1 =>
        if start = '1' and di(1) = '1' then
          nstate <= s2;
        end if;
      when s2 =>
        detect <= '1';
        if start = '1' then
          nstate <= s2;
        end if;
    end case;
  end process uasn;

end beh;
