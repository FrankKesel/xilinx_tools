library ieee;
use ieee.std_logic_1164.all;

entity fsmueb is
   port( 
      clk    : in     std_logic;
      din    : in     std_logic;
      res    : in     std_logic;
      start  : in     std_logic;
      detect : out    std_logic
   );
end fsmueb ;

architecture beh of fsmueb is

begin

end beh;
