library ieee;
use ieee.std_logic_1164.all;

entity fsmueb_tb is
end fsmueb_tb ;

architecture sim of fsmueb_tb is

   -- component declarations
   component fsmueb
   port (
      clk    : in     std_logic ;
      din    : in     std_logic ;
      res    : in     std_logic ;
      start  : in     std_logic ;
      detect : out    std_logic 
   );
   end component;

   -- internal signal declarations
   signal clk    : std_logic := '0';
   signal detect : std_logic;
   signal din    : std_logic := '0';
   signal res    : std_logic := '1';
   signal start  : std_logic := '0';
  
   constant clk_hz : integer := 100e6;
   constant clk_period : time := 1 sec / clk_hz;


begin
   -- instance port mappings.
   uut : fsmueb
      port map (
         clk    => clk,
         din    => din,
         res    => res,
         start  => start,
         detect => detect
      );

   clk <= not clk after clk_period / 2; -- clock generator

   stimulus : process
   begin
      wait for clk_period*2;
      -- please enter your code here:
      wait;
   end process;

end;
