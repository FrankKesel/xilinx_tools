library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity a3 is
    port ( clk : in std_logic;
           reset : in std_logic;
           fibo_out : out std_logic_vector (15 downto 0)
        );
end a3;

architecture behavioral of a3 is

begin


end behavioral;
