library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity a3 is
    port ( clk : in std_logic;
           reset : in std_logic;
           fibo_out : out std_logic_vector (15 downto 0)
        );
end a3;

architecture behavioral of a3 is
    signal fibo, old_fibo : unsigned(15 downto 0);
begin

reg: process(clk, reset)
begin
    if reset = '0' then
        fibo <= "0000000000000001";
        old_fibo <= "0000000000000001";
    elsif rising_edge(clk) then
        fibo <= fibo + old_fibo;
        old_fibo <= fibo;
    end if;
end process reg;
fibo_out <= std_logic_vector(fibo);
end behavioral;
