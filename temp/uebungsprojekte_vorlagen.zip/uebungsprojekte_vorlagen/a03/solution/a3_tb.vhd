library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity a3_tb is
end;

architecture sim of a3_tb is

  component a3
      port ( clk : in std_logic;
             reset : in std_logic;
             fibo_out : out std_logic_vector (15 downto 0));
  end component;

  constant clk_hz : integer := 100e6;
  constant clk_period : time := 1 sec / clk_hz;

  signal clk: std_logic := '1';
  signal reset: std_logic;
  signal fibo_out: std_logic_vector(15 downto 0);

begin

  clk <= not clk after clk_period / 2;

  uut: a3 port map ( 
    clk      => clk,
    reset    => reset,
    fibo_out => fibo_out );

  stimulus: process
  begin
  
    reset <= '0';
    wait for clk_period;
    reset <= '1';
    wait for clk_period/2;
    wait for clk_period;
    assert fibo_out = std_logic_vector(to_unsigned(2, 16))
          report "fibo is wrong.";
    wait for clk_period;
    assert fibo_out = std_logic_vector(to_unsigned(3, 16))
          report "fibo is wrong.";
    wait for clk_period;
    assert fibo_out = std_logic_vector(to_unsigned(5, 16))
          report "fibo is wrong.";
    wait for clk_period;
    assert fibo_out = std_logic_vector(to_unsigned(8, 16))
          report "fibo is wrong.";
    wait for clk_period;
    assert fibo_out = std_logic_vector(to_unsigned(13, 16))
          report "fibo is wrong.";
    report "test finished!";                    

    wait;
  end process;

end;
  
